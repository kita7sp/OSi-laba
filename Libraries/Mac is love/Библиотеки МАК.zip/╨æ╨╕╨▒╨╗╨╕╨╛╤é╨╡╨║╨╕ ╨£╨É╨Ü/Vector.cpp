#include "Vector.h"
#include "Number.h"
#include <cmath>

Vector::Vector(const Number& x, const Number& y) : x(x), y(y) {}

Number Vector::getX() const { 
    return x; 
}

Number Vector::getY() const { 
    return y; 
}

Number Vector::radius() const {
    double x_val = x.getValue();
    double y_val = y.getValue();
    double radius_value = sqrt(x_val * x_val + y_val * y_val);
    return newNumber(radius_value);
}

Number Vector::angle() const {
    double x_val = x.getValue();
    double y_val = y.getValue();
    double angle_value = atan2(y_val, x_val);
    return newNumber(angle_value);
}

Vector Vector::operator+(const Vector& other) const {
    return Vector(x + other.x, y + other.y);
}

Vector ZERO_VECTOR(newNumber(0.0), newNumber(0.0));
Vector ONE_VECTOR(newNumber(1.0), newNumber(1.0));