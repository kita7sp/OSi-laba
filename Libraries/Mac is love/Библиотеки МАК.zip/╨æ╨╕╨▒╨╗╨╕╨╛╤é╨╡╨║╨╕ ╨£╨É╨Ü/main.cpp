#include <iostream>
#include <iomanip>
#include "Number.h"
#include "Vector.h"

int main() {
    std::cout << "Тест Number\n";

    Number a = newNumber(10.0);
    Number b = newNumber(3.0);

    std::cout << "a = " << a.getValue() << "\n";
    std::cout << "b = " << b.getValue() << "\n";
    std::cout << "a + b = " << (a + b).getValue() << "\n";
    std::cout << "a - b = " << (a - b).getValue() << "\n";
    std::cout << "a * b = " << (a * b).getValue() << "\n";
    std::cout << "a / b = " << (a / b).getValue() << "\n";
    std::cout << "ZERO = " << ZERO.getValue() << "\n";
    std::cout << "ONE = " << ONE.getValue() << "\n";

    std::cout << "\nТест Vector\n";

    Vector v1(newNumber(3.0), newNumber(4.0));
    Vector v2(newNumber(1.0), newNumber(2.0));
    Vector v3 = v1 + v2;

    std::cout << std::fixed << std::setprecision(3);

    std::cout << "v1 = (" << v1.getX().getValue() << ", " << v1.getY().getValue() << ")\n";
    std::cout << "v2 = (" << v2.getX().getValue() << ", " << v2.getY().getValue() << ")\n";
    std::cout << "v1 + v2 = (" << v3.getX().getValue() << ", " << v3.getY().getValue() << ")\n";

    std::cout << "Длина v1: " << v1.radius().getValue() << " (ожидается: 5.000)\n";
    std::cout << "Угол v2: " << v2.angle().getValue() << " радиан\n";

    std::cout << "ZERO_VECTOR = (" << ZERO_VECTOR.getX().getValue() << ", "
        << ZERO_VECTOR.getY().getValue() << ")\n";
    std::cout << "ONE_VECTOR = (" << ONE_VECTOR.getX().getValue() << ", "
        << ONE_VECTOR.getY().getValue() << ")\n";
}

/*
rm -f *.o *.a *.dylib main && g++ -c Number.cpp -o Number.o && ar rcs libNumber.a Number.o && g++ -c Vector.cpp -o Vector.o -fPIC && g++ -dynamiclib -o libVector.dylib Vector.o libNumber.a && g++ -c Main.cpp -o Main.o && g++ -o main Main.o -L. -lNumber -lVector && export DYLD_LIBRARY_PATH=.:$DYLD_LIBRARY_PATH && ./main
*/