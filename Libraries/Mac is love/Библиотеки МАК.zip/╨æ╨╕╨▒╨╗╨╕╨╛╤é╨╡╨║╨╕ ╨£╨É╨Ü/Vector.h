#ifndef VECTOR_H
#define VECTOR_H

#include "Number.h"

class Vector {
private:
    Number x;
    Number y;

public:
    Vector(const Number& x, const Number& y);
    
    Number getX() const;
    Number getY() const;
    
    Number radius() const;
    Number angle() const;
    
    Vector operator+(const Vector& other) const;
};

extern Vector ZERO_VECTOR;
extern Vector ONE_VECTOR;

#endif